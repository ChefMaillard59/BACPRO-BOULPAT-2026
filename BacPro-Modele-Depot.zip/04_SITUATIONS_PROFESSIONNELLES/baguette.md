# Situation : Baguette

Objectifs et déroulé de production.