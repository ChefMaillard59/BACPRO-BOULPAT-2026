# Bloc 1 Production

Compétences liées aux productions boulangères et pâtissières.